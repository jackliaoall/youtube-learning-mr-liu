import * as tf from '@tensorflow/tfjs';

// 定义一个线性回归模型
const model = tf.sequential();
model.add(tf.layers.dense({units: 1, inputShape: [1]}));

// 模型训练所需要的损失函数和优化器
model.compile({loss: 'meanSquaredError', optimizer: 'sgd'});

// 生成训练数据集
const xs = tf.tensor2d([1, 2, 3, 4], [4, 1]);
const ys = tf.tensor2d([1, 3, 5, 7], [4, 1]);


model.fit(xs, ys, {epochs: 10}).then(() => {
    // 输出预测结果
    model.predict(tf.tensor2d([5], [1, 1])).print();
});



